import copy
import torch.nn.functional as F
from torch.utils.data.dataloader import DataLoader
from torch import stack, no_grad
from models.model_feature import ResNet18
from client import Client
from torch.nn.functional import softmax, log_softmax
import random
import torch
import numpy as np
import torch.nn as nn



class Server(object):
    def __init__(self,
                 args,
                 train_data_list,
                 global_train_dataset,
                 global_test_dataset,
                 global_student,
                 batch_size_inspect: int,
                 batch_size_psoeva: int,
                 lamda
                ):
        super(Server, self).__init__()
        self.device = args.device
        self.global_rounds = args.global_rounds
        self.batch_size = args.batch_size
        self.num_clients = args.num_clients
        self.join_ratio = args.join_ratio
        self.join_clients = int(self.num_clients * self.join_ratio)
        self.train_data_list = train_data_list
        self.global_train_dataset = global_train_dataset
        self.global_test_dataset = global_test_dataset
        self.global_student = copy.deepcopy(global_student)
        self.global_student.to(self.device)
        self.dict_global_params = self.global_student.state_dict()
        self.batch_size_inspect = batch_size_inspect
        self.batch_size_psoeva=batch_size_psoeva
        self.lamda = lamda
        self.random_state = np.random.RandomState(args.seed)
        self.ce_loss = nn.CrossEntropyLoss()
        self.weight=None
        self.warm_round = 0

        self.clients = []
        self.clients_bad = []
        self.list_dicts_local_params = []
        self.list_dicts_good_local_params = []
        self.test_acc = []
        self.test_loss = []
        self.set_clients(args, Client)  #客户端处理

    def set_clients(self, args, Client):
        for i in range(self.num_clients):
            client = Client(
                args=args,
                data_client=self.train_data_list[i],
                global_student=copy.deepcopy(self.global_student),
            )
            self.clients.append(client)
            self.clients_bad.append(client)

    #随机选择客户端
    def select_clinet_indexes(self):
        selected_client_indexes = list(
            np.random.choice(list(range(self.num_clients)), self.join_clients, replace=False))
        return selected_client_indexes

    #为选择客户端发送全局学生模型参数
    def send_models(self):
        assert (len(self.selected_client_indexes) > 0)
        for select_id in self.selected_client_indexes:
            self.clients[select_id].download_params(copy.deepcopy(self.dict_global_params))

    def aggregate_parameters(self):
        if self.weight is None:
            self.weight = [1.0/ len(self.selected_client_indexes)] * len(self.selected_client_indexes)
        list_weight=[np.int16(weight * 10000) for weight in self.weight]
        for name_param in self.dict_global_params:
            list_values_param = []
            # 计算客户端的该参数值*权重，并添加进list_values_param中
            for dict_local_params, weight in zip(self.list_dicts_local_params, list_weight):    #FedPSO消融
                list_values_param.append(dict_local_params[name_param] * weight)
            # list_values_param和/权重和
            value_global_param = sum(list_values_param) /sum(list_weight)
            self.dict_global_params[name_param] = value_global_param  # 更新全局参数字典值
        self.global_student.load_state_dict(self.dict_global_params)

    def pso(self):
        #iter_num是迭代次数,particle_num是粒子数
        #c1、c2是学习因子,W是惯性因子,r是随机量
        iter_num = 5
        particle_num = 5
        Wmin = 0.6
        Wmax = 1.0
        W1 = 1.0
        c1 = 1.5
        c2 = 1.5
        r = random.random()
        # FedDPSO实验
        self.weight = [1.0 / len(self.selected_client_indexes)] * len(self.selected_client_indexes)     #FedPSO消融
        self.aggregate_parameters()

        accuracy, loss = self.pso_evaluate()
        # 初始化粒子群
        particles = []
        for i in range(particle_num):
            # 随机初始化0-1之间的粒子
            particle = [random.random() for i in range(len(self.weight))]
            particles.append(particle)
        weight_list = [self.weight]*particle_num
        # 初始化p_best、g_best
        p_best = particles
        p_best_accuracy = [accuracy] * particle_num
        g_best = self.weight
        g_best_accuracy = accuracy

        # 迭代
        for i in range(1,iter_num+1):
            r=3 * r * (1 - r)
            W2 = Wmin + ((Wmax - Wmin) * float(i / iter_num))
            W1 = W1 - (r * (Wmax - Wmin + 1 - W2) * float(1 / iter_num))
            for j in range(particle_num):
                # 更新粒子速度
                for k in range(len(weight_list[j])):
                    particles[j][k] = (W1 * particles[j][k] + W1 * c1 * random.random() * (p_best[j][k] - weight_list[j][k])
                                       + W2 * c2 * random.random() * (g_best[k] - weight_list[j][k]))
                # 更新粒子权重
                for k in range(len(weight_list[j])):
                    weight_list[j][k] = weight_list[j][k] + particles[j][k]
                    weight_list[j][k] = 0 if (weight_list[j][k] < 0 or weight_list[j][k] > 1) else weight_list[j][k]
                # 权重归一化
                weight_total=sum(weight_list[j])
                if weight_total == 0:
                    weight_list[j] = [1.0 / len(weight_list[j]) for _ in weight_list[j]]
                else:
                    weight_list[j] = [weight / weight_total for weight in weight_list[j]]

                self.weight = weight_list[j]
                self.aggregate_parameters()
                acc, loss = self.pso_evaluate()
                # 更新粒子群最优权重
                if acc > p_best_accuracy[j]:
                    p_best[j] = copy.deepcopy(weight_list[j])
                    p_best_accuracy[j] = acc
            # 更新全局最优权重
            for j in range(particle_num):
                if p_best_accuracy[j] > g_best_accuracy:
                    g_best = copy.deepcopy(p_best[j])
                    g_best_accuracy = copy.deepcopy(p_best_accuracy[j])

        print('g_best:{}'.format(g_best))
        # 返回最优权重
        return g_best

    def compute_uncertainty(self):
        client_indexes = self.selected_client_indexes
        list_dicts_local_params = self.list_dicts_local_params  #获取所有客户端的本地参数字典
        total_indices_unlabeled = [i for i in range(len(self.global_train_dataset))]  #创建一个包含全局蒸馏数据集索引的列表
        #从全局蒸馏数据集中随机选择一批未标记的样本索引
        batch_indices_unlabeled = self.random_state.choice(total_indices_unlabeled, self.batch_size_inspect, replace=False)

        images_unlabeled = []
        for idx in batch_indices_unlabeled:
            image, _ = self.global_train_dataset[idx]
            images_unlabeled.append(image)  #将图像添加到未标记样本的图像列表images_unlabeled中
        images_unlabeled = stack(images_unlabeled, dim=0)  #将未标记样本的图像堆叠成一个张量
        images_unlabeled = images_unlabeled.to(self.device)
        list_var = {}  #初始化一个空字典，用于存储每个客户端的不确定性指标
        list_key_good = []
        list_key_bad = []  #初始化两个空列表，用于存储良好客户端和不良客户端的索引
        list_softmax = []  #初始化一个空列表，用于存储每个客户端的softmax值
        ii = 0
        for dict_local_params in list_dicts_local_params:
            for name_param in self.dict_global_params:  #遍历全局参数字典的键
                self.dict_global_params[name_param] = dict_local_params[name_param]
            self.global_student.load_state_dict(self.dict_global_params)  #加载更新后的全局参数到全局学生模型

            #初始化两个空张量，用于存储不确定性和预测概率
            uncen = torch.tensor([]).cuda()
            pred_prob = torch.tensor([]).cuda()

            for step in range(10):
                with no_grad():
                    _, local_drop, local_logits = self.global_student(images_unlabeled)  #对未标记样本进行推理，获取预测结果和dropout结果
                    drop_softmax = softmax(local_drop, dim=1).view(-1, 10, 1)  #计算dropout结果的softmax值
                    pred_prob = torch.cat([pred_prob, drop_softmax], dim=-1)  #将每次推理的softmax值拼接起来
            list_softmax.append(pred_prob.reshape(-1).cpu().detach().numpy())  #将每个客户端的softmax值添加到list_softmax列表中

            uncen = pred_prob.mean(-1)  #计算每个客户端的平均预测概率
            per_uncen = -torch.sum(torch.log(uncen) * uncen, dim=-1)  # 计算每个客户端的不确定性指标
            list_var[client_indexes[ii]] = torch.sum(per_uncen)  #将每个客户端的不确定性指标存储在list_var字典中
            ii = ii + 1

        list_var = sorted(list_var.items(), key=lambda x:x[1], reverse=False)  #按不确定性指标对客户端进行排序

        sum_value = 0
        for key, value in list_var:
            sum_value = sum_value + value
        #判断是否为良好客户端
        for key, value in list_var:
            value = value / sum_value
            if value <= self.lamda:
                list_key_good.append(key)
            else:
                list_key_bad.append(key)
        return list_key_good,list_key_bad

    def train(self):
        bad_log = []  #初始化一个空列表bad_log，用于记录坏客户端的信息
        for i in range(1, self.global_rounds + 1):  #循环全局轮次
            print('Round {} has begun.'.format(i))
            # warm_up
            if i <= self.warm_round:  #热身轮次
                self.selected_client_indexes = self.select_clinet_indexes()  #进行客户端选择
                print('selected_client_indexes: {}'.format(self.selected_client_indexes))
                self.send_models()  #发送全局模型
                for select_id in self.selected_client_indexes:
                    self.clients[select_id].train()  #客户端训练
                    self.list_dicts_local_params.append(self.clients[select_id].upload_params())  #客户端训练参数添加进list_dicts_local_params中

                self.aggregate_parameters()  #预热轮次聚合
                acc, loss = self.evaluate()  #评估准确率和损失

                self.test_acc.append(acc)
                self.test_loss.append(loss)
                #重置
                self.list_dicts_local_params = []

                print('Round {} result'.format(i))
                print('Acc:{:.2f}%'.format(acc*100))
                print('total_loss:{:.5f}'.format(loss))

            else:
                self.selected_client_indexes= self.select_clinet_indexes()
                print('selected_client_indexes: {}'.format(self.selected_client_indexes))
                self.send_models()
                print('bad index: {}'.format(bad_log))
                for select_id in self.selected_client_indexes:
                    if select_id in bad_log:
                        self.clients[select_id].bad_train()  #噪声客户端特殊训练
                        self.list_dicts_local_params.append(self.clients[select_id].upload_params())
                    else:
                        self.clients[select_id].train()
                        self.list_dicts_local_params.append(self.clients[select_id].upload_params())

                #计算不确定性，得到选中的干净和噪声噪声客户端索引
                selected_good_client_indexes, selected_bad_client_indexes = self.compute_uncertainty()
                self.selected_good_client_indexes = selected_good_client_indexes
                self.selected_bad_client_indexes = selected_bad_client_indexes

                #若选择出的客户端id不在噪声客户端日志中，添加进去
                for id in selected_bad_client_indexes:
                    if id not in bad_log:
                        bad_log.append(id)
                # 干净客户端select_id的上传参数添加到干净客户端本地参数列表中
                for select_id in self.selected_good_client_indexes:
                    self.list_dicts_good_local_params.append(self.clients[select_id].upload_params())

                print('good_client: {} , bad_client: {}'.format(self.selected_good_client_indexes,self.selected_bad_client_indexes))


                # print('----------weight calculate with PSO----------')
                self.weight = self.pso()
                self.aggregate_parameters()
                acc, loss = self.evaluate()

                self.test_acc.append(acc)
                self.test_loss.append(loss)
                #重置
                self.list_dicts_local_params = []
                self.list_dicts_good_local_params = []

                print('Round {} result'.format(i))
                print('Acc:{:.2f}%'.format(acc*100))
                print('total_loss:{:.5f}'.format(loss))

    def pso_evaluate(self):
        self.global_student.eval()  #将全局学生模型设置为评估模式
        with torch.no_grad():
            train_loader =DataLoader(self.global_train_dataset,
                       batch_size=self.batch_size_psoeva,
                       shuffle=True)  #创建一个训练数据加载器，用于加载全局验证数据集

            num_corrects = 0
            total_loss = 0.0

            for data_batch in train_loader:
                images, labels = data_batch
                images, labels = images.to(self.device), labels.to(self.device)
                _, _, outputs = self.global_student(images)

                loss = self.ce_loss(outputs, labels)  #计算交叉熵损失
                total_loss += loss.item()  #累加损失值

                _, predicts = torch.max(outputs, -1)  #获取输出中预测概率最大的类别作为预测结果
                num_corrects += sum(torch.eq(predicts.cpu(), labels.cpu())).item()  # 统计预测正确的数量

            accuracy = num_corrects / len(self.global_train_dataset)  #计算测试准确率

        return accuracy, total_loss

    def evaluate(self):
        self.global_student.eval()  #将全局学生模型设置为评估模式
        with torch.no_grad():
            test_loader =DataLoader(self.global_test_dataset,
                       batch_size=self.batch_size,
                       shuffle=True)  #创建一个测试数据加载器，用于加载全局测试数据集

            num_corrects = 0
            total_loss = 0.0

            for data_batch in test_loader:
                images, labels = data_batch
                images, labels = images.to(self.device), labels.to(self.device)
                _, _, outputs = self.global_student(images)

                loss = self.ce_loss(outputs, labels)  #计算交叉熵损失
                total_loss += loss.item()  #累加损失值

                _, predicts = torch.max(outputs, -1)  #获取输出中预测概率最大的类别作为预测结果
                num_corrects += sum(torch.eq(predicts.cpu(), labels.cpu())).item()  # 统计预测正确的数量

            accuracy = num_corrects / len(self.global_test_dataset)  #计算测试准确率

        return accuracy, total_loss