from torchvision import datasets
from torchvision import transforms

import copy
import numpy as np
import random

import torchvision
import torch
from torch.utils.data import random_split
from .utils.noisify import noisify_label


from .utils.dataset import classify_label, show_clients_data_distribution
from .utils.sampling import client_iid_indices, clients_non_iid_indices


def get_cifar10(args):
    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    data_full = datasets.CIFAR10(args.data_path, train=True, download=True, transform=transform_train)  #args.data_path_cifar100
    data_local_train_size = int(0.95 * len(data_full))
    data_global_train_size = len(data_full) - data_local_train_size
    data_local_train, data_global_train = random_split(data_full, [data_local_train_size, data_global_train_size])
    data_global_test = datasets.CIFAR10(args.data_path, train=False, transform=transform_test)

    if args.iid:
        list_client_indices = client_iid_indices(data_local_train, args.num_clients)
    else:
        list_label_indices = classify_label(data_local_train, args.num_classes)
        list_client_indices = clients_non_iid_indices(list_label_indices, args.num_classes, args.num_clients, args.non_iid_alpha, args.seed)

    # show_clients_data_distribution(data_local_train, list_client_indices, args.num_classes)
    return data_local_train,data_global_train, data_global_test, list_client_indices