import argparse
import os
def args_parser():
    parser = argparse.ArgumentParser()
    path_dir = os.path.dirname(__file__)
    # dataset
    parser.add_argument('--data_path', type=str, default='../data/cifar10', help='cifar10, cifar100')
    parser.add_argument('--num_data_train', type=int, default=47500)
    parser.add_argument('--gpu', default='0', help='comma separated list of GPU(s) to use.')
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--num_classes', type=int, default=10)
    parser.add_argument('--num_clients', type=int, default=50)
    parser.add_argument('--global_rounds', type=int, default=100)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--batch_size_psoeva', type=int, default=32)
    parser.add_argument('--batch_size_inspect', type=int, default=128)
    parser.add_argument('--join_ratio', type=float, default=0.2)
    parser.add_argument('--global_learning_rate', type=float, default=0.05)
    parser.add_argument('--local_learning_rate', type=float, default=0.05)
    parser.add_argument('--local_steps', type=int, default=10)
    parser.add_argument('--threshold', default=0.60, type=float,help='pseudo label threshold')
    parser.add_argument('--noise_type', type=str, default='symmetric',help='noise type of each clients')
    parser.add_argument('--noise_rate_list', type=list, default=[],help="noise rate of each clients")
    parser.add_argument('--num_gradual', type=int, default=10, help='T_k')
    #noise rate
    parser.add_argument('--alpha', type=float, default=0.3,help="Control the first parameter of Beta Distribution.")
    parser.add_argument('--beta', type=float, default=0.5,help="Control the second parameter of Beta Distribution.")
    parser.add_argument('--lamda', type=float, default=0.12,help="Control the threshold of uncertainty value.")
    parser.add_argument('--delta', type=float, default=1.0, help="Loss dynamic adjustment of hyperparameters.")
    #non-iid
    parser.add_argument('--iid', type=bool, default=False)
    parser.add_argument('--non_iid_alpha', type=float, default=0.7)
    #distill
    parser.add_argument('--temperature', type=float, default=2)
    parser.add_argument('--ld', type=float, default=0.5, help='threshold of distillation aggregate')

    parser.add_argument('--eval_step', default=90, type=int , help='number of eval steps to run')

    #other
    parser.add_argument('--seed', type=int, default=7)
    args = parser.parse_args()
    return args