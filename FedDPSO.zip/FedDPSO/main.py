import os
os.environ["KMP_DUPLICATE_LIB_OK"]="True"
from datetime import datetime
from server import Server
from dataset.get_cifar10 import get_cifar10
from dataset.utils.dataset import Indices2Dataset
from models.model_feature import ResNet18
from dataset.utils.noisify import noisify_label
from torch.utils.data.dataloader import DataLoader
from options import args_parser
import numpy as np
import copy
import random
import torch
from torch import optim
import torch.nn as nn
ce_loss = nn.CrossEntropyLoss()
def get_train_label(data_local_train, index_list):
    trian_label_list = []
    for index in index_list:
        label = data_local_train[index][1]       #统计本地训练数据标签
        trian_label_list.append(label)
    return trian_label_list

def label_rate(test_label_list, train_label_list):
    true_num = 0
    for true_label, nos_label in zip(test_label_list, train_label_list):
        if true_label == nos_label:
            true_num += 1
    noise_rate = 1.0 - (true_num / len(test_label_list))       #计算测试数据标签和训练数据标签相同的比例
    return noise_rate

#通过为这些库设置随机种子，可以确保每次运行代码时生成相同的随机数，从而实现结果的可重复性。
def set_seed(seed):
    torch.manual_seed(seed)  # cpu随机种子
    torch.cuda.manual_seed_all(seed)  # gpu随机种子
    np.random.seed(seed)  # numpy随机种子
    random.seed(seed)  # random and transforms随机种子
    torch.backends.cudnn.deterministic = True  # 对cudnn使用确定性算法有助于结果可重复性

#获取和设置GPU的ID
def get_set_gpus(gpu_ids):
    # get gpu ids
    if len(gpu_ids) > 1:
        str_ids = gpu_ids.split(',')
        gpus = []
        for str_id in str_ids:
            id = int(str_id)
            if id >= 0:
                gpus.append(id)
    else:
        gpus = [int(gpu_ids)]
    # set gpu ids
    if len(gpus) > 0:
        torch.cuda.set_device(gpus[0])
        return gpu_ids

def main(args):
    prev_time = datetime.now()  #获取开始时间
    print(torch.cuda.device_count())  #查看可用GPU数量
    print(torch.cuda.is_available())  #查看GPU是否可用
    if args.gpu:
        gpus = get_set_gpus(args.gpu)
        print('==>Currently use GPU: {}'.format(gpus))

    data_local_train,data_global_train, data_global_test, list_client_indices= get_cifar10(args)  #获取数据
    model = ResNet18(resnet_size=18, scaling=4,                                                #构建模型
                        group_norm_num_groups=None,freeze_bn=False,
                        freeze_bn_affine=False, num_classes=args.num_classes)

    #add noise
    train_data_list = []
    label_list = []
    noise_rate = []
    alpha = args.alpha  #控制Beta分布的第一个参数
    beta = args.beta    #控制Beta分布的第二个参数
    beta_samples = np.random.beta(alpha, beta, size=args.num_clients)
    # noise_rate_list = np.sort(beta_samples)  #从Beta分布中生成args.num_clients个样本进行排序
    noise_rate_list = np.round(beta_samples, 6)  # 将噪声率四舍五入到小数点后四位
    args.noise_rate_list = noise_rate_list
    print('每个客户的预设噪声率：', args.noise_rate_list)

    for i in range(args.num_clients):
        current_client_index_list = list_client_indices[i]  #当前客户端索引列表
        train_label_list = get_train_label(data_local_train, current_client_index_list)  #训练数据标签列表
        num_classes = train_label_list
        test_label_list = copy.deepcopy(train_label_list)
        noise_index = int(len(list_client_indices[i]) * args.noise_rate_list[i]) #噪声标签索引
        #对于训练标签列表中索引小于noise_index的标签，使用noisify_label函数对真实标签进行噪声处理，生成一个噪声标签，并将其替换原来的真实标签
        for idx, true_label in enumerate(train_label_list[:noise_index]):
            noisy_label = noisify_label(true_label, num_classes, noise_type=args.noise_type)
            train_label_list[idx] = noisy_label

        client_noise_rate=label_rate(test_label_list, train_label_list)
        indices2data = Indices2Dataset(data_local_train)  #获取本地训练数据的图像、标签、索引、长度
        data_client = indices2data
        data_client.load(list_client_indices[i], train_label_list)  #加载客户端索引、标签数据列表
        train_data_list.append(data_client)
        label_list.append(train_label_list)
        noise_rate.append(client_noise_rate)
    print('每个客户的真实噪声率：', noise_rate)

    server = Server(args=args,
                    train_data_list=train_data_list,
                    global_train_dataset=data_global_train,
                    global_test_dataset=data_global_test,
                    global_student=model,
                    batch_size_inspect=args.batch_size_inspect,
                    batch_size_psoeva=args.batch_size_psoeva,
                    lamda=args.lamda
                    )
    server.train()

    #保留测试准确率较高的10个数据
    acc = server.test_acc
    acc.sort()
    acc = acc[90:]
    final_acc=sum(acc) / len(acc)
    print('train finished---> final_acc={:.2f}%'.format(final_acc*100))

    #输出运行时间
    cur_time = datetime.now()
    h, remainder = divmod((cur_time - prev_time).seconds, 3600)
    m, s = divmod(remainder, 60)
    time_str = "train time %02d:%02d:%02d" % (h, m, s)
    print(time_str)


if __name__ == '__main__':
    set_seed(0)
    args = args_parser()
    main(args)