# _*_ codeing : utf-8 _*_
# @Softwore : PyCharm
# @version : python3.11
# @Author : mao
# @File : new
# @Softwore : 2024/3/26
import random
import numpy as np
import matplotlib.pyplot as plt
'''
# 生成Beta分布的随机数
beta_samples = np.random.beta(0.1, 0.1, 100)

# 绘制直方图
plt.hist(beta_samples, bins=10, edgecolor='black',color='blue')
plt.ylim(0, 100)
plt.xlabel('Noise ratio')
plt.ylabel('Frequency')
plt.title('probability distribution of Beta=(0.1, 0.1)')
plt.show()
'''

'''
#alpha_1变化曲线
def calculate_alpha(alpha_min, alpha_max, alpha_1, T):
    alpha_1_values = [alpha_1]
    r_0 = random.random()

    for t in range(1, T+1):
        alpha_2 = alpha_min + (alpha_max - alpha_min) * t / T
        r_0 = 3 * r_0 * (1 - r_0)
        alpha_t_1 = alpha_1_values[-1] - r_0 * (alpha_max - alpha_min + 1 - alpha_2) / T
        alpha_1_values.append(alpha_t_1)

    return alpha_1_values

# 参数设置
alpha_min = 0.6
alpha_max = 1
alpha_1 = 1
T = 5

alpha_1_values = calculate_alpha(alpha_min, alpha_max, alpha_1, T)
print(alpha_1_values)

# 生成图形
plt.figure()
plt.plot(range(T+1), alpha_1_values, marker='o')
plt.xlabel('Time Step (t)')
plt.ylabel('Alpha 1 Value')
plt.title('Change of Alpha 1 over Time')
plt.grid(True)
plt.show()
'''