import torch
import copy
import torch.nn as nn
from torch import optim
import torch.nn.functional as F
from torch.nn.functional import softmax, log_softmax
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler

class Client(object):
    def __init__(self, args, data_client, global_student):
        super(Client, self).__init__()
        self.device = args.device
        self.batch_size = args.batch_size
        self.local_learning_rate = args.local_learning_rate
        self.local_steps = args.local_steps
        self.num_classes = args.num_classes
        self.eval_step = args.eval_step
        self.delta = args.delta
        self.data_client = data_client

        self.model = copy.deepcopy(global_student)
        self.model.to(self.device)
        self.model_classifier = global_student.classifier
        self.model_classifier.to(self.device)
        self.local_teacher = copy.deepcopy(global_student)
        self.local_teacher.to(self.device)
        self.optimizer = optim.SGD(self.model.parameters(), lr=self.local_learning_rate)

        self.ce_loss = nn.CrossEntropyLoss()
        self.temperature = args.temperature
        self.threshold =args.threshold
        self.data_path = args.data_path


    def download_params(self, global_params):
        self.model.load_state_dict(global_params)

    def upload_params(self):
        return copy.deepcopy(self.model.state_dict())


    def train(self):
        self.model.train()
        data_loader = DataLoader(dataset=self.data_client,
                                 batch_size=self.batch_size,
                                 shuffle=True)
        for step in range(self.local_steps):
            for images, labels, indexs in data_loader:
                images, labels = images.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                _, _, output = self.model(images)
                loss = self.ce_loss(output, labels)
                loss.backward()
                self.optimizer.step()


    def bad_train(self):
        self.model.train()
        labeled_data_loader = DataLoader(dataset=self.data_client,
                                 batch_size=self.batch_size,
                                 shuffle=True)
        for step in range(self.local_steps):
            for inputs, label, indexs in labeled_data_loader:
                inputs, label = inputs.to(self.device), label.to(self.device)
                self.optimizer.zero_grad()
                _, _, student_logits = self.model(inputs)
                #伪标签损失
                pseudo_label = torch.softmax(student_logits.detach() / self.temperature, dim=-1)
                max_probs, targets = torch.max(pseudo_label, dim=-1)
                mask = max_probs.ge(self.threshold).float()
                weighted_loss = self.ce_loss(student_logits, targets) * mask
                valid_samples = mask.sum()
                pseudo_loss = weighted_loss.sum() / valid_samples if valid_samples > 0 else 0
                #模型蒸馏损失
                with torch.no_grad():
                    _, _, teacher_logits = self.local_teacher(inputs)
                y_student = F.log_softmax(student_logits / self.temperature, dim=1)
                y_teacher = F.softmax(teacher_logits / self.temperature, dim=1)
                distill_loss = F.kl_div(y_student, y_teacher, reduction='batchmean')  # 计算KL散度损失

                self.delta = pseudo_loss / (pseudo_loss + distill_loss + 1e-8)
                loss = self.delta * pseudo_loss + (1 - self.delta) * distill_loss
                loss.backward()
                self.optimizer.step()

